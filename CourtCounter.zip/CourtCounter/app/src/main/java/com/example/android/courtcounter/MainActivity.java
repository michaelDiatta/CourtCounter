package com.example.android.courtcounter;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    int score1 = 0;
    int score2 = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void displayScoreT1(int score){
        TextView scoreTextView = (TextView) findViewById(R.id.score1_text_view);
        scoreTextView.setText("" + score);
    }
    public void displayScoreT2(int score){
        TextView scoreTextView = (TextView) findViewById(R.id.score2_text_view);
        scoreTextView.setText("" + score);
    }

    public void addPointsForTeam1(int points){
        score1 += points;
        displayScoreT1(score1);

    }
    public void addPointsForTeam2(int points){
        score2 += points;
        displayScoreT2(score2);
    }
    public void addOneS1(View view){
        addPointsForTeam1(1);
    }

    public void addOneS2(View view){
        addPointsForTeam2(1);
    }

    public void addTwoS1(View view){
        addPointsForTeam1(2);
    }

    public void addTwoS2(View view){
        addPointsForTeam2(2);
    }

    public void addThreeS1(View view){
        addPointsForTeam1(3);
    }

    public void addThreeS2(View view){
        addPointsForTeam2(3);
    }

    public void reset(View view){
        score1 = 0;
        score2 = 0;
        displayScoreT1(score1);
        displayScoreT2(score2);
    }
}
